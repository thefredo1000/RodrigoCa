README:
This is the GameBoy Advance version of the game ROULT 4403: The Game, which is not finished and there is no plan to finish it. This is a taste of what the arcade machine was in the Laguna FRC Regional, hope you like it since it is playable but it doesn’t have scores.

FUNFACT:
There was a plan to release it to the Xbox One console, but Microsoft said no. :/